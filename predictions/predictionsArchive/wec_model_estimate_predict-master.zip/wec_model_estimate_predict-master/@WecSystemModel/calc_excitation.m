function [fe, feTime, varargout] = calc_excitation(obj, eta, dt)
% Calculates the time domain excitation force via convolution.
% If the sampling rate of the irf is greater than eta, then eta values will
% be upsampled to match by using linear interpolation. If they have the
% same sampling rate, it will be left be.
%
% NOTES: dt/dtIrf MUST BE AN INTEGER. OTHERWISE THIS WILL BREAK.
%
% Inputs:
%   eta: vector containing water surface elevation
%   dt: scalar - sample interval of eta in seconds
%
% [Fe, feTime] = calc_excitation(WecModel, eta, dt)



% Created 7/28/2014
% Bradley Ling
%
% Updated 8/15: need to scale irf to the sampling time. Should implement
% trapeziodal integration for the future.
%
% Updated 8/18: Implemented trapeziodal integration for convolution.
% Tested results with many uniform waves and compared to frequency domain
% results.
%
% Updated 8/22: changed interpolation to cubic

% Updated 8/25: Squashed some bugs with trimming output. Also optimized
% this process to use less memory and calcs.
%  
% References:
% Ruehl Thesis 2011; Bosma et. al. 2013



% -------------------------------------------------------------------------
% Lets interpolate eta so it has the same sampling rate as the irf
%  CUBIC INTERPOLATION CURRENTLY IMPLEMENTED
%
% NOTES: ** dt/dtIrf MUST BE AN INTEGER. OTHERWISE THIS WILL BREAK.
%        ** the time range of the irf must be symmetrical. 

irf = obj.feIrf;
dtIrf = irf.t(2) - irf.t(1);

ratio = round(dt/dtIrf);

% Check to make sure ratio is acceptable
if abs(ratio - dt/dtIrf) > 1e-5
    error('sampling rates are not compatable for interpolation')
elseif ratio ~= 1
    etaInterpTime = dtIrf .* ( 0:(length(eta)*ratio - (ratio - 1)) );
    etaInterp     = interp1(dt .* (0:length(eta)-1), eta, etaInterpTime, 'pchip');
else
    % don't do interpolation
    %warning('No Interpolation performed')
    etaInterp = eta;
    etaInterpTime = dtIrf .* [0:length(eta)-1];
end



% Implement Convolution via trapeziodal rule
fe = nan(size(etaInterp));
halfWidth = (length(irf.irf) - 1 ) / 2;
startIdx = halfWidth+1;
endIdx   = length(etaInterp)-halfWidth;
idxIrf = -halfWidth:halfWidth;


coeff = (irf.t(end) - irf.t(1)) / (4 .* halfWidth); 
for it = startIdx:endIdx;
    fx = irf.irf .* etaInterp(idxIrf + it);
    fe(it) = coeff * sum( [fx fx(2:end-1)] );
end


% Trim the output
trimmedTime = etaInterpTime(~isnan(fe));
idxKeep = ~isnan(fe);
fe = fe(idxKeep);
if nargout == 3, varargout{1} = etaInterp(idxKeep); end
feTime = floor( (min(trimmedTime):dt:max(trimmedTime)) ./ dt) .* dt;

idx = dsearchn(trimmedTime', feTime');
fe = fe(idx);




