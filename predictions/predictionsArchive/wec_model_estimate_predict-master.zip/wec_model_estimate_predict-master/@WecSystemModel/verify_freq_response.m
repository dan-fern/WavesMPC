function verify_freq_response(obj, freqs)
% This function compares the simulated frequency response with the values
% provided form ANSYS AQWA

